#include <stdio.h>

int main()
{
 char name[300],b[20];
 int i,ser=0;

 printf("Name: "); scanf("%s",&name);
 for(i=0;i<strlen(name);i++) ser+=name[i];
 ser*=0xDEADBEEF;
 sprintf(b,"%X",ser);
 printf("K%c%cE-W%c%cL-S%c%cH-I%c%cT\n",b[0],b[1],b[2],b[3],b[4],b[5],b[6],b[7]);
 system("pause");
}