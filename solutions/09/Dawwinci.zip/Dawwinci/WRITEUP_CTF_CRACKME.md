# Fatmike Crackme #9 - Publish-Ready CTF Walkthrough (Deep Dive)

## TL;DR

This crackme is solved by reconstructing runtime semantics, not by patching random branches and not by global brute force.

The effective path was:

1. Trace the exact validation entry from UI to `.pc` routines.
2. Rebuild the real `.pc` decryptor offline (custom ChaCha-like stream, runtime-derived key).
3. Verify decryption with hard gates (`0x40A000`, `0x40A025`, `0x40A1CE`).
4. Model VM-style `int3` branch dispatch (resource-driven conditional jumps).
5. Execute `sub_40A1CE` as an oracle and solve `sub_40A025` block-by-block.

Recovered serial:

`D3FE-A7ED-BAAD-C0D3`

---

## 1. Challenge Mindset and Why This One Is Tricky

This binary combines two independent pain points:

- **Encrypted code region** (`.pc`) that is decrypted on the fly.
- **Post-decrypt anti-disassembly** via `int3`-driven virtualized branching.

That means two common mistakes will waste a lot of time:

1. Trusting pseudo-C output in `.pc` too early.
2. Assuming that once `.pc` is decrypted, control flow is normal linear x86.

For this challenge, decryption is only half the job. The other half is restoring true branch semantics.

---

## 2. Environment and Files Used

Main artifacts:

- `Crackme.exe`
- `Crackme.exe.c` (decompile dump)
- `strings.txt`
- `scripts/decrypt_pc_blocks.py` (offline decryption utility)

Generated during solve:

- `pc_decrypted.bin`
- `res_457_type10.bin` (VM branch table resource)
- `slice_1ce_2blocks.bin` (spot-check around helper start)

Core Python dependencies:

- `pefile`
- `unicorn` (for dynamic `step` oracle)
- optional `capstone` (disassembly readability)

---

## 3. First Step: Find the Real Check Path

From UI event handling:

- `MainDialog_OnCheckButtonClick` reads user key from control `1006` using `GetDlgItemTextA`.
- It calls `ValidateKey(...)`.
- `ValidateKey` eventually dispatches into `.pc`:
  - `sub_40A000`
  - `sub_40A025`

This is the choke point. Once this is confirmed, everything unrelated can be ignored.

Why this matters:

- You avoid wasting time on cosmetic UI/runtime framework code.
- You can focus directly on serialization logic and the protected execution path.

---

## 4. Why `.pc` Decompiler Output Looks Corrupted

Even after some static recovery, `.pc` routines look noisy because:

- lots of embedded `int3`
- fake instruction streams from linear decode
- `push imm; ret` jump shaping
- branch meaning split between local instruction stream and external VM handler tables

So the correct strategy is:

- trust bytes and execution behavior
- distrust linear pseudo-C in protected regions

---

## 5. Reconstructing the `.pc` Decryptor

## 5.1 Identifying the Decrypt Function Chain

The key function is `Vm_DecryptBlock` (seen in `Crackme.exe.c`).

Its high-level behavior:

1. Copy encrypted bytes.
2. Compute section-relative offset.
3. Build cipher state (`ChaChaSetKeyAndNonce`).
4. Finalize for this offset (`ChaChaFinalize`).
5. XOR 16 bytes (`ChaChaXorKeystream(..., 0x10)`).

This gives exact offline decryption behavior.

## 5.2 Reconstructing the Cipher Variant Correctly

### Constants

The internal constants are not standard ChaCha sigma words:

- `0xB979379E`
- `0x157C4A7F`
- `0x60C09CF3`
- `0x34C8ED5C`

### Nonce

Fixed two-dword nonce values from code:

- `218893066` (`0x0D0C0B0A`)
- `286265102` (`0x11100F0E`)

### Core round behavior

Recovered quarter-round uses:

- add/xor/rotate pattern with rotates `16, 20, 24, 25`
- 10 double-rounds (20 total rounds)

### State layout

16 x 32-bit words:

- `[0..3]` constants
- `[4..11]` key (8 dwords)
- `[12..13]` counter (64-bit)
- `[14..15]` nonce (64-bit)

---

## 6. Where the Key Comes From (`f630aa38...`)

The decryption key is dynamic and tied to `.text`:

1. Read `.text` raw bytes using PE section metadata.
2. Temporarily patch the **last byte** of `.text` to `0x90`.
3. Compute SHA-256 of this patched buffer.

Result:

`f630aa38d57297375d645559c334fd50d55ca1d177d2655a042351cf69244bf2`

This 32-byte digest is the ChaCha key.

Important detail:

- You must hash `.text` **raw data size**, not virtual size.
- Hashing the wrong range is one of the easiest ways to get wrong output that still looks "randomly plausible".

---

## 7. Offset-to-Keystream Mapping (Critical Detail)

Decryption is done in 16-byte chunks, but keystream is generated in 64-byte blocks.

For section-relative offset `ofs`:

1. `counter64 = ofs >> 6`
2. Generate 64-byte keystream block for that counter
3. `idx = ofs & 0x3F`
4. Use `keystream[idx:idx+16]`
5. `dec16 = enc16 XOR ks16`

If you set counter directly to `ofs` instead of `ofs >> 6`, output fails.

---

## 8. Hard Gates to Confirm Decryption Is Correct

I treated decrypt success as binary (pass/fail), not subjective.

Mandatory gates:

1. `0x40A000` must decode to validator constant initialization.
2. `0x40A024` must be `ret` and `0x40A025` must begin function prologue.
3. `0x40A1CE` must begin with `55 8B EC` prologue.

If any gate fails, stop and fix decryptor mapping first.

---

## 9. Extracting VM Handler Metadata

Even correct decrypted bytes are still partially virtualized.

The branch metadata is in PE resource:

- type `10`
- name/id `0x457`
- dumped as `res_457_type10.bin`

Structure:

- dword[0] = entry count (`1536`)
- then entries of 16 bytes each:
  - `rva`
  - `cond_id`
  - `disp_base`
  - `instr_len`

This table is used to resolve what each `int3` site really does.

---

## 10. Reconstructing `int3` Conditional Dispatch

`Vm_CheckConditionalJump` maps condition IDs to logic over EFLAGS (plus one ECX-based case).

At runtime hook time:

- On interrupt 3:
  - `ip = eip - 1`
  - locate handler by `rva = ip - image_base`
  - evaluate condition with current flags
  - branch target:
    - true: `ip + instr_len + disp_base`
    - false: `ip + instr_len`

Without this step, `sub_40A1CE` looks incoherent and cannot be used as a solver primitive.

---

## 11. Rebuilding the Top-Level Validator Semantics

## 11.1 `sub_40A000`

Writes five target dwords:

- `0x865DBB47`
- `0x0A6EB190`
- `0x20476C33`
- `0x1C8A7693`
- `0x59FEBDFB`

## 11.2 `sub_40A025`

Recovered logic:

1. Reject unless `len(serial) == 19`.
2. Initialize:
   - `state = 0xCAFEBABE`
   - `idx = 0`
   - `acc = 0`
3. Per byte:
   - `state = step(state, serial[idx])`
   - `idx += 1`
4. Every 4 chars (`idx` in 4,8,12,16):
   - `acc |= state ^ target[block]`
   - reset state:
     - `state = idx * 0x112233 - 0x35014542` (mod 2^32)
5. Final at `idx == 19`:
   - `acc |= state ^ target[4]`
6. Accept iff `acc == 0`.

This structure is the key reason block decomposition works.

---

## 12. Rebuilding `step(state, ch)` as an Oracle

I did not rely on static lifting for all branches.

Instead:

1. Map decrypted `.pc` into Unicorn x86-32.
2. Start execution at `0x40A1CE`.
3. Pass args using stdcall stack layout.
4. Place a sentinel return address (`HLT` page) and stop there.
5. Hook `int3` and apply handler-table logic.
6. Return EAX as next state.

This gives exact runtime-consistent transition behavior.

Performance was good enough to brute-force constrained blocks.

---

## 13. Why Global Brute Force Is Wrong Here

Naive global search over 19 chars is infeasible.

But because state resets every 4 chars, constraints split into independent groups:

- block 1: 4 chars
- block 2: 4 chars
- block 3: 4 chars
- block 4: 4 chars
- block 5: 3 chars

Known start states:

- B1: `0xCAFEBABE`
- B2: `0xCB43438A`
- B3: `0xCB87CC56`
- B4: `0xCBCC5522`
- B5: `0xCC10DDEE`

Known targets are from `sub_40A000`.

---

## 14. Search Strategy and Practical Choices

Candidate alphabet used:

- uppercase letters `A-Z`
- digits `0-9`
- dash `-`

Reasoning:

- common license formatting conventions
- practical reduction of search space
- still broad enough to avoid overfitting

Per 4-char block method:

1. enumerate first 3 chars
2. compute intermediate state
3. try 4th char and keep exact matches

Final block (3 chars) brute-forced directly.

Each block produced a unique hit in this alphabet.

---

## 15. Recovered Block Results

- Block 1 (`start=0xCAFEBABE`, target `0x865DBB47`) -> `D3FE`
- Block 2 (`start=0xCB43438A`, target `0x0A6EB190`) -> `-A7E`
- Block 3 (`start=0xCB87CC56`, target `0x20476C33`) -> `D-BA`
- Block 4 (`start=0xCBCC5522`, target `0x1C8A7693`) -> `AD-C`
- Block 5 (`start=0xCC10DDEE`, target `0x59FEBDFB`) -> `0D3`

Concatenated serial:

`D3FE-A7ED-BAAD-C0D3`

---

## 16. Final Validation and Sanity Checks

Reconstructed `validate(serial)` confirmed:

- all five checkpoint states matched exactly
- final accumulator became zero
- mutations at sampled indices failed

This confirms semantic correctness rather than accidental collision.

---

## 17. Repro Steps (Exact Order)

### Step A - Decrypt full `.pc`

```bash
python scripts/decrypt_pc_blocks.py --exe Crackme.exe --out pc_decrypted.bin
```

Expected signals:

- key printed as `f630aa38...44bf2`
- gates passed (`40A000 / 40A025 / 40A1CE`)

### Step B - Spot-check helper bytes

```bash
python scripts/decrypt_pc_blocks.py --exe Crackme.exe --offset 0x1CE --blocks 2 --out slice_1ce_2blocks.bin
```

Expect first decrypted bytes around helper prologue.

### Step C - Extract handler table

```bash
python scripts/decrypt_pc_blocks.py --exe Crackme.exe --extract-handlers --handlers-out res_457_type10.bin
```

Expect count `1536`.

### Step D - Build `step` oracle and solve blocks

Use Unicorn + `int3` dispatch hook with `res_457_type10.bin` metadata and `Vm_CheckConditionalJump` semantics.

### Step E - Validate final serial

Check full `sub_40A025` model and run mutation tests.

---

## 18. Common Failure Cases and How to Detect Them

1. **Wrong SHA-256 range**
   - Symptom: key differs, gates fail immediately.

2. **Forgot `.text` last-byte patch (`0x90`)**
   - Symptom: wrong key with otherwise correct implementation.

3. **Wrong counter mapping (`ofs` vs `ofs>>6`)**
   - Symptom: decryption looks random with occasional false positives.

4. **Ignoring VM `int3` semantics**
   - Symptom: helper disassembly appears nonsense; solver never converges.

5. **Signed/unsigned branch confusion in condition emulation**
   - Symptom: almost-correct paths, no exact target matches.

6. **Missing 32-bit wraparound**
   - Symptom: drift in state after several operations.

---

## 19. What Actually Made This Solvable

Three decisions made the difference:

1. Treat decryption as a strict engineering reconstruction problem (with hard gates).
2. Treat `sub_40A1CE` as executable semantics, not textual disassembly.
3. Use block decomposition from validator reset structure.

Once those three pieces were in place, the challenge became deterministic.

---

## 20. Final Answer

Valid serial:

`D3FE-A7ED-BAAD-C0D3`

---

## Appendix A - Minimal Key Derivation Snippet

```python
import pefile, hashlib

blob = open("Crackme.exe", "rb").read()
pe = pefile.PE(data=blob)
text = next(s for s in pe.sections if s.Name.rstrip(b"\x00") == b".text")
start = text.PointerToRawData
end = start + text.SizeOfRawData
buf = bytearray(blob[start:end])
buf[-1] = 0x90
print(hashlib.sha256(buf).hexdigest())
# f630aa38d57297375d645559c334fd50d55ca1d177d2655a042351cf69244bf2
```

## Appendix B - Minimal Block Decrypt Concept

```text
for ofs in range(0, pc_size, 16):
    counter = ofs >> 6
    idx = ofs & 0x3F
    ks64 = chacha_block(counter, key, nonce)
    dec[ofs:ofs+16] = enc[ofs:ofs+16] XOR ks64[idx:idx+16]
```

## Appendix C - Command Log for Decrypt and Block Solver

### C.1 Full `.pc` decrypt

```bash
python decrypt_pc_blocks.py
[+] key = f630aa38d57297375d645559c334fd50d55ca1d177d2655a042351cf69244bf2
[+] patched .text last byte: 0x00 -> 0x90
[+] .pc size: 1536 bytes (96 x 16-byte blocks)
[+] verification gates passed (40A000 / 40A025 / 40A1CE)
[+] full decrypted .pc written: pc_decrypted.bin
```

What this confirms:

- SHA-256 key derivation is correct.
- `.text` patching was applied correctly (`0x90` on last byte).
- Full `.pc` region decrypt succeeded.
- Gate checks for the three critical routines passed before solver stage.

### C.2 Block-by-block serial solve (from repository root)

```bash
python solve_serial_blocks.py --block 1 --first-only --workers 8
python solve_serial_blocks.py --block 2 --first-only --workers 8 --dash-first
python solve_serial_blocks.py --block 3 --first-only --workers 8 --pattern XXXX-XXXX-XXXX-XXXX
python solve_serial_blocks.py --block 4 --first-only --workers 8 --pattern XXXX-XXXX-XXXX-XXXX
python solve_serial_blocks.py --block 5 --first-only --workers 8 --pattern XXXX-XXXX-XXXX-XXXX
```

Option meaning:

- `--block N`: solves only checkpoint block `N` (1..5).
- `--first-only`: stops at first exact hit, useful because each block had a unique candidate.
- `--workers 8`: parallel brute-force workers.
- `--dash-first`: enforces `'-'` as first char in that block (used for block 2).
- `--pattern XXXX-XXXX-XXXX-XXXX`: constrains candidates to key-like format while solving.
