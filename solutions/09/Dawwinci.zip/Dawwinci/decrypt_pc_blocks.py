#!/usr/bin/env python3
"""
Fatmike Crackme #9 - .pc decryption utility

Features:
- derives the real 32-byte key from patched .text (SHA-256)
- decrypts full .pc section OR selected 16-byte blocks
- optional extraction of VM handler table resource (type 10, name 0x457)
- verification gates for 0x40A000 / 0x40A025 / 0x40A1CE
"""

import argparse
import hashlib
import struct
import sys
from pathlib import Path

import pefile

CHACHA_CONSTS = (0xB979379E, 0x157C4A7F, 0x60C09CF3, 0x34C8ED5C)
NONCE_DWORDS = (218893066, 286265102)  # 0x0D0C0B0A, 0x11100F0E


def auto_int(v: str) -> int:
    return int(v, 0)


def ror32(x: int, n: int) -> int:
    x &= 0xFFFFFFFF
    return ((x >> n) | ((x << (32 - n)) & 0xFFFFFFFF)) & 0xFFFFFFFF


def qr(st, a, b, c, d):
    st[a] = (st[a] + st[b]) & 0xFFFFFFFF
    st[d] ^= st[a]
    st[d] = ror32(st[d], 16)

    st[c] = (st[c] + st[d]) & 0xFFFFFFFF
    st[b] ^= st[c]
    st[b] = ror32(st[b], 20)

    st[a] = (st[a] + st[b]) & 0xFFFFFFFF
    st[d] ^= st[a]
    st[d] = ror32(st[d], 24)

    st[c] = (st[c] + st[d]) & 0xFFFFFFFF
    st[b] ^= st[c]
    st[b] = ror32(st[b], 25)


def chacha_block(initial_state_words):
    x = list(initial_state_words)

    # 10 double-rounds = 20 rounds
    for _ in range(10):
        # column rounds
        qr(x, 0, 4, 8, 12)
        qr(x, 1, 5, 9, 13)
        qr(x, 2, 6, 10, 14)
        qr(x, 3, 7, 11, 15)

        # diagonal rounds
        qr(x, 0, 5, 10, 15)
        qr(x, 1, 6, 11, 12)
        qr(x, 2, 7, 8, 13)
        qr(x, 3, 4, 9, 14)

    out = [(x[i] + initial_state_words[i]) & 0xFFFFFFFF for i in range(16)]
    return b"".join(struct.pack("<I", w) for w in out)


def get_section(pe: pefile.PE, name: bytes):
    for s in pe.sections:
        if s.Name.rstrip(b"\x00") == name:
            return s
    raise ValueError(f"Missing section {name!r}")


def derive_key_from_text(exe_blob: bytes, pe: pefile.PE):
    text = get_section(pe, b".text")
    start = text.PointerToRawData
    end = start + text.SizeOfRawData

    text_raw = bytearray(exe_blob[start:end])
    if not text_raw:
        raise ValueError(".text section raw data is empty")

    original_last = text_raw[-1]
    text_raw[-1] = 0x90  # exact runtime patch behavior
    key = hashlib.sha256(text_raw).digest()
    return key, original_last


def decrypt_pc_block16(enc16: bytes, key32: bytes, sec_rel_offset: int) -> bytes:
    key_words = struct.unpack("<8I", key32)
    n0, n1 = NONCE_DWORDS

    state = [
        CHACHA_CONSTS[0], CHACHA_CONSTS[1], CHACHA_CONSTS[2], CHACHA_CONSTS[3],
        *key_words,
        0, 0,
        n0, n1,
    ]

    block_index = sec_rel_offset >> 6
    state[12] = block_index & 0xFFFFFFFF
    state[13] = (block_index >> 32) & 0xFFFFFFFF

    keystream64 = chacha_block(state)
    idx = sec_rel_offset & 0x3F
    ks = keystream64[idx:idx + len(enc16)]
    return bytes(a ^ b for a, b in zip(enc16, ks))


def decrypt_pc_full(exe_blob: bytes, pe: pefile.PE, key32: bytes):
    pc = get_section(pe, b".pc")
    start = pc.PointerToRawData
    end = start + pc.SizeOfRawData
    enc = exe_blob[start:end]

    out = bytearray(enc)
    for ofs in range(0, len(enc), 16):
        out[ofs:ofs + 16] = decrypt_pc_block16(enc[ofs:ofs + 16], key32, ofs)
    return bytes(out), enc


def verify_gates(dec_pc: bytes):
    # 0x40A000: mov [ecx], 0x865DBB47
    if dec_pc[0:6] != bytes.fromhex("c70147bb5d86"):
        return False, "gate fail: 0x40A000 constant init mismatch"

    # 0x40A024 ret ; 0x40A025 push ebp
    if dec_pc[0x24] != 0xC3 or dec_pc[0x25] != 0x55:
        return False, "gate fail: 0x40A025 prologue boundary mismatch"

    # 0x40A1CE: push ebp; mov ebp, esp
    if dec_pc[0x1CE:0x1D1] != bytes.fromhex("558bec"):
        return False, "gate fail: 0x40A1CE prologue mismatch"

    return True, "ok"


def extract_handler_table(pe: pefile.PE, out_path: Path):
    if not hasattr(pe, "DIRECTORY_ENTRY_RESOURCE"):
        print("[!] no resource directory present")
        return

    for t in pe.DIRECTORY_ENTRY_RESOURCE.entries:
        if getattr(t, "id", None) != 10:
            continue
        for n in t.directory.entries:
            if getattr(n, "id", None) != 0x457:
                continue
            lang = n.directory.entries[0]
            rva = lang.data.struct.OffsetToData
            size = lang.data.struct.Size
            off = pe.get_offset_from_rva(rva)
            blob = pe.__data__[off:off + size]
            out_path.write_bytes(blob)
            cnt = struct.unpack_from("<I", blob, 0)[0]
            print(f"[+] handler table written: {out_path} ({len(blob)} bytes, count={cnt})")
            return

    print("[!] resource type=10 name=0x457 not found")


def print_block_table(pc_enc: bytes, key32: bytes, offset: int, blocks: int):
    if blocks <= 0:
        raise ValueError("--blocks must be >= 1")

    end = offset + blocks * 16
    if offset < 0 or end > len(pc_enc):
        raise ValueError("requested range is outside .pc bounds")

    print("idx,offset,enc16,dec16")
    for i in range(blocks):
        ofs = offset + i * 16
        enc16 = pc_enc[ofs:ofs + 16]
        dec16 = decrypt_pc_block16(enc16, key32, ofs)
        print(f"{i},{ofs:#06x},{enc16.hex()},{dec16.hex()}")


def main():
    ap = argparse.ArgumentParser(description="Decrypt Fatmike #9 .pc section")
    ap.add_argument("--exe", default="Crackme.exe", help="Path to Crackme.exe")
    ap.add_argument("--out", default="pc_decrypted.bin", help="Output for full decrypt or slice bytes")
    ap.add_argument("--offset", type=auto_int, default=None, help="Section-relative .pc offset (hex like 0x1CE)")
    ap.add_argument("--blocks", type=int, default=1, help="Number of 16-byte blocks (for offset mode)")
    ap.add_argument("--extract-handlers", action="store_true", help="Extract resource type=10,name=0x457")
    ap.add_argument("--handlers-out", default="res_457_type10.bin", help="Output path for handler table")
    ap.add_argument("--no-verify", action="store_true", help="Skip full decrypt verification gates")
    args = ap.parse_args()

    exe_path = Path(args.exe)
    if not exe_path.exists():
        print(f"[-] file not found: {exe_path}")
        sys.exit(1)

    exe_blob = exe_path.read_bytes()
    pe = pefile.PE(data=exe_blob, fast_load=False)

    key, orig_last = derive_key_from_text(exe_blob, pe)
    dec_pc, enc_pc = decrypt_pc_full(exe_blob, pe, key)

    print(f"[+] key = {key.hex()}")
    print(f"[+] patched .text last byte: 0x{orig_last:02x} -> 0x90")
    print(f"[+] .pc size: {len(enc_pc)} bytes ({len(enc_pc)//16} x 16-byte blocks)")

    if not args.no_verify:
        ok, msg = verify_gates(dec_pc)
        if not ok:
            print(f"[-] verification failed: {msg}")
            sys.exit(2)
        print("[+] verification gates passed (40A000 / 40A025 / 40A1CE)")

    if args.offset is None:
        out_path = Path(args.out)
        out_path.write_bytes(dec_pc)
        print(f"[+] full decrypted .pc written: {out_path}")
    else:
        print_block_table(enc_pc, key, args.offset, args.blocks)
        start = args.offset
        end = start + args.blocks * 16
        slice_dec = dec_pc[start:end]
        out_path = Path(args.out)
        out_path.write_bytes(slice_dec)
        print(f"[+] decrypted slice written: {out_path} ({len(slice_dec)} bytes)")

    if args.extract_handlers:
        extract_handler_table(pe, Path(args.handlers_out))


if __name__ == "__main__":
    main()
