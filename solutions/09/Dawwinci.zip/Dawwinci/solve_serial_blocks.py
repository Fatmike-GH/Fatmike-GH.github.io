#!/usr/bin/env python3
"""
Fatmike Crackme #9 - block-by-block serial solver.

What this script does:
1) derives decrypt key from .text (same method as decrypt_pc_blocks.py)
2) decrypts .pc
3) loads VM int3 conditional jump table from resource type=10, name=0x457
4) executes sub_40A1CE via Unicorn with proper int3 dispatch semantics
5) solves validator in 5 independent blocks: 4+4+4+4+3

Performance helpers:
- --block N      solve only one block (N in 1..5)
- --list-blocks  print block start/target/length
- --first-only   stop block solve after first matching candidate
- --pattern      apply positional constraints (e.g., XXXX-XXXX-XXXX-XXXX)
- --dash-first   reorder alphabet to try '-' first
- --workers N    parallelize single-block first-hit search by first-char prefixes
"""

import argparse
import itertools
import struct
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import pefile
from unicorn import Uc, UC_ARCH_X86, UC_MODE_32
from unicorn.unicorn_const import UC_HOOK_INTR
from unicorn.x86_const import UC_X86_REG_EAX, UC_X86_REG_ECX, UC_X86_REG_EFLAGS, UC_X86_REG_EIP, UC_X86_REG_ESP

# local import from scripts folder
SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from decrypt_pc_blocks import decrypt_pc_full, derive_key_from_text, get_section, verify_gates  # noqa: E402


TARGETS = [
    0x865DBB47,
    0x0A6EB190,
    0x20476C33,
    0x1C8A7693,
    0x59FEBDFB,
]
BLOCK_LENGTHS = [4, 4, 4, 4, 3]
BLOCK_OFFSETS = [0, 4, 8, 12, 16]
DEFAULT_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-"
WILDCARDS = {"X", "x", "?", "*"}

_WORKER_STEP_FN = None


def to_signed32(v: int) -> int:
    return v - 0x100000000 if v & 0x80000000 else v


def block_start_states() -> list[int]:
    starts = [0xCAFEBABE]
    for idx in (4, 8, 12, 16):
        starts.append((idx * 0x112233 - 0x35014542) & 0xFFFFFFFF)
    return starts


def print_block_meta(starts: list[int]):
    print("[+] Block metadata:")
    for i in range(5):
        print(
            f"    Block {i+1}: start=0x{starts[i]:08X} "
            f"target=0x{TARGETS[i]:08X} len={BLOCK_LENGTHS[i]}"
        )


def reorder_alphabet_dash_first(alphabet: bytes) -> bytes:
    if b"-" not in alphabet:
        return alphabet
    out = []
    seen = set()
    for ch in b"-" + alphabet:
        if ch not in seen:
            seen.add(ch)
            out.append(ch)
    return bytes(out)


def build_block_charsets(block_index: int, alphabet: bytes, pattern: str | None) -> list[bytes]:
    length = BLOCK_LENGTHS[block_index]
    if pattern is None:
        return [alphabet] * length

    if len(pattern) != 19:
        raise ValueError("--pattern must have exactly 19 characters")

    base = BLOCK_OFFSETS[block_index]
    charsets: list[bytes] = []

    for i in range(length):
        pch = pattern[base + i]
        if pch in WILDCARDS:
            charsets.append(alphabet)
        else:
            charsets.append(pch.encode("ascii"))

    return charsets


def load_handler_table(pe: pefile.PE) -> dict[int, tuple[int, int, int]]:
    """
    Resource format (type=10, name=0x457):
      dword count
      dword unknown
      then count entries of 4 dwords:
        [rva, cond_id, disp_base, instr_len]
    """
    if not hasattr(pe, "DIRECTORY_ENTRY_RESOURCE"):
        raise RuntimeError("No resource directory")

    blob = None
    for typ in pe.DIRECTORY_ENTRY_RESOURCE.entries:
        if getattr(typ, "id", None) != 10:
            continue
        for name in typ.directory.entries:
            if getattr(name, "id", None) != 0x457:
                continue
            lang = name.directory.entries[0]
            rva = lang.data.struct.OffsetToData
            size = lang.data.struct.Size
            off = pe.get_offset_from_rva(rva)
            blob = pe.__data__[off : off + size]
            break

    if blob is None:
        raise RuntimeError("Resource type=10 name=0x457 not found")

    count = struct.unpack_from("<I", blob, 0)[0]
    handlers: dict[int, tuple[int, int, int]] = {}
    base = 8
    for i in range(count):
        rva, cond_id, disp_base, instr_len = struct.unpack_from("<IIII", blob, base + i * 16)
        handlers[rva] = (cond_id, to_signed32(disp_base), instr_len)
    return handlers


def vm_check_cond(cond_id: int, eflags: int, ecx_val: int) -> int:
    """Reimplementation of Vm_CheckConditionalJump logic."""
    v2 = eflags & 0xFFFFFFFF

    if cond_id == 1:
        return (~(v2 >> 6)) & 1
    if cond_id == 2:
        return 1
    if cond_id == 3:
        return (v2 >> 7) & 1
    if cond_id == 4:
        return (~v2) & 1
    if cond_id == 5:
        if (v2 & 0x40) == 0 and ((((v2 >> 7) & 0xFF) ^ ((eflags >> 11) & 0xFF)) & 1) == 0:
            return 0
        return 1
    if cond_id == 6:
        return 1 if (v2 & 0x41) == 0 else 0
    if cond_id == 7:
        v5 = (~((v2 >> 11) & 0xFF)) & 0xFF
        return (((v2 >> 7) & 0xFF) ^ v5) & 1
    if cond_id == 8:
        return (v2 >> 2) & 1
    if cond_id == 9:
        return (v2 >> 11) & 1
    if cond_id == 10:
        return 1 if (v2 & 0x41) != 0 else 0
    if cond_id == 11:
        return 1 if (ecx_val & 0xFFFFFFFF) == 0 else 0
    if cond_id == 12:
        return (~(v2 >> 2)) & 1
    if cond_id == 13:
        return (v2 >> 6) & 1
    if cond_id == 14:
        return ((v2 >> 7) ^ (v2 >> 11)) & 1
    if cond_id == 15:
        return (~(v2 >> 7)) & 1
    if cond_id == 16:
        return (~(v2 >> 11)) & 1
    if cond_id == 17:
        if (v2 & 0x40) != 0 or ((((v2 >> 7) & 0xFF) ^ ((eflags >> 11) & 0xFF)) & 1) != 0:
            return 0
        return 1
    if cond_id == 18:
        return v2 & 1
    return 0


class StepOracle:
    def __init__(
        self,
        image_base: int,
        pc_rva: int,
        pc_bytes: bytes,
        handlers: dict[int, tuple[int, int, int]],
        func_rva: int = 0xA1CE,
    ):
        self.image_base = image_base
        self.pc_rva = pc_rva
        self.func_addr = image_base + func_rva
        self.handlers = handlers
        self.error = None

        self.sentinel = 0x00600000
        self.stack_base = 0x00700000
        self.stack_top = self.stack_base + 0x3F000

        self.mu = Uc(UC_ARCH_X86, UC_MODE_32)

        self.mu.mem_map(0x00400000, 0x00200000)
        self.mu.mem_write(image_base + pc_rva, pc_bytes)

        self.mu.mem_map(self.sentinel, 0x1000)
        self.mu.mem_write(self.sentinel, b"\x90")

        self.mu.mem_map(self.stack_base, 0x40000)

        self.mu.hook_add(UC_HOOK_INTR, self._on_intr)

    def _on_intr(self, uc: Uc, intno: int, _):
        if intno != 3:
            self.error = f"Unhandled interrupt {intno}"
            uc.emu_stop()
            return

        eip = uc.reg_read(UC_X86_REG_EIP)
        ip = (eip - 1) & 0xFFFFFFFF
        rva = ip - self.image_base

        h = self.handlers.get(rva)
        if h is None:
            self.error = f"No int3 handler entry for RVA 0x{rva:X}"
            uc.emu_stop()
            return

        cond_id, disp_base, instr_len = h
        eflags = uc.reg_read(UC_X86_REG_EFLAGS)
        ecx_val = uc.reg_read(UC_X86_REG_ECX)
        take = vm_check_cond(cond_id, eflags, ecx_val)

        next_ip = (ip + instr_len + (disp_base if take else 0)) & 0xFFFFFFFF
        uc.reg_write(UC_X86_REG_EIP, next_ip)

    def step(self, state: int, ch: int) -> int:
        esp = self.stack_top

        def push_u32(v: int):
            nonlocal esp
            esp -= 4
            self.mu.mem_write(esp, struct.pack("<I", v & 0xFFFFFFFF))

        push_u32(ch)
        push_u32(state)
        push_u32(self.sentinel)

        self.error = None

        self.mu.reg_write(UC_X86_REG_ESP, esp)
        self.mu.reg_write(UC_X86_REG_ECX, 0x11111111)
        self.mu.reg_write(UC_X86_REG_EIP, self.func_addr)

        self.mu.emu_start(self.func_addr, self.sentinel)

        if self.error:
            raise RuntimeError(self.error)

        return self.mu.reg_read(UC_X86_REG_EAX) & 0xFFFFFFFF


def build_step_with_cache(oracle: StepOracle, use_cache: bool):
    if not use_cache:
        return oracle.step

    cache: dict[tuple[int, int], int] = {}

    def step_cached(state: int, ch: int) -> int:
        key = (state & 0xFFFFFFFF, ch & 0xFF)
        if key in cache:
            return cache[key]
        out = oracle.step(state, ch)
        cache[key] = out
        return out

    return step_cached


def _worker_init(image_base, pc_rva, pc_bytes, handlers, func_rva, use_cache):
    global _WORKER_STEP_FN
    oracle = StepOracle(image_base, pc_rva, pc_bytes, handlers, func_rva=func_rva)
    _WORKER_STEP_FN = build_step_with_cache(oracle, use_cache=use_cache)


def _worker_search_task(task):
    """
    task = (prefix_bytes, start_state_after_prefix, target_state, charsets_rest)
    Returns a string solution or None.
    """
    global _WORKER_STEP_FN
    prefix, start_state, target_state, charsets_rest = task

    frontier = [(prefix, start_state)]
    depth_total = len(charsets_rest)

    if depth_total == 0:
        return prefix.decode("ascii") if start_state == target_state else None

    for d in range(depth_total):
        is_last = d == (depth_total - 1)
        nxt = []
        chars = charsets_rest[d]

        for pref, st in frontier:
            for ch in chars:
                ns = _WORKER_STEP_FN(st, ch)
                if is_last:
                    if ns == target_state:
                        return (pref + bytes([ch])).decode("ascii")
                else:
                    nxt.append((pref + bytes([ch]), ns))

        if not is_last:
            frontier = nxt

    return None


def solve_block_parallel_first(
    step_fn,
    start_state: int,
    target_state: int,
    charsets: list[bytes],
    block_index: int,
    workers: int,
    image_base: int,
    pc_rva: int,
    pc_bytes: bytes,
    handlers: dict[int, tuple[int, int, int]],
    func_rva: int,
    use_cache: bool,
) -> list[str]:
    t0 = time.time()

    if not charsets:
        return []

    first_chars = charsets[0]
    if len(first_chars) == 0:
        return []

    tasks = []
    for ch in first_chars:
        st1 = step_fn(start_state, ch)
        tasks.append((bytes([ch]), st1, target_state, charsets[1:]))

    max_workers = max(1, min(workers, len(tasks)))

    executor = ProcessPoolExecutor(
        max_workers=max_workers,
        initializer=_worker_init,
        initargs=(image_base, pc_rva, pc_bytes, handlers, func_rva, use_cache),
    )

    try:
        futures = [executor.submit(_worker_search_task, t) for t in tasks]
        for fut in as_completed(futures):
            sol = fut.result()
            if sol is not None:
                dt = time.time() - t0
                fanout = "x".join(str(len(cs)) for cs in charsets)
                print(
                    f"[+] Block {block_index}: start=0x{start_state:08X} target=0x{target_state:08X} "
                    f"len={len(charsets)} fanout={fanout} -> first hit in {dt:.2f}s "
                    f"(parallel workers={max_workers})"
                )
                print(f"    - {sol}")
                return [sol]
    finally:
        executor.shutdown(cancel_futures=True)

    return []


def solve_block(
    step_fn,
    start_state: int,
    target_state: int,
    charsets: list[bytes],
    block_index: int,
    first_only: bool = False,
) -> list[str]:
    t0 = time.time()

    frontier: list[tuple[bytes, int]] = [(b"", start_state)]
    solutions: list[str] = []

    length = len(charsets)
    fanout = "x".join(str(len(cs)) for cs in charsets)

    for depth in range(length):
        is_last = depth == (length - 1)
        nxt: list[tuple[bytes, int]] = []

        for pref, st in frontier:
            for ch in charsets[depth]:
                ns = step_fn(st, ch)
                if is_last:
                    if ns == target_state:
                        solutions.append((pref + bytes([ch])).decode("ascii"))
                        if first_only:
                            dt = time.time() - t0
                            print(
                                f"[+] Block {block_index}: start=0x{start_state:08X} target=0x{target_state:08X} "
                                f"len={length} fanout={fanout} -> first hit in {dt:.2f}s"
                            )
                            print(f"    - {solutions[0]}")
                            return solutions
                else:
                    nxt.append((pref + bytes([ch]), ns))

        if not is_last:
            frontier = nxt

    dt = time.time() - t0
    print(
        f"[+] Block {block_index}: start=0x{start_state:08X} target=0x{target_state:08X} "
        f"len={length} fanout={fanout} -> {len(solutions)} solution(s) in {dt:.2f}s"
    )
    for s in solutions[:10]:
        print(f"    - {s}")
    return solutions


def validate_serial(step_fn, serial: str) -> bool:
    if len(serial) != 19:
        return False

    state = 0xCAFEBABE
    acc = 0
    ti = 0

    for idx, ch in enumerate(serial.encode("ascii"), 1):
        state = step_fn(state, ch)

        if idx % 4 == 0 and idx < 19:
            acc |= (state ^ TARGETS[ti])
            acc &= 0xFFFFFFFF
            ti += 1
            state = (idx * 0x112233 - 0x35014542) & 0xFFFFFFFF

    acc |= (state ^ TARGETS[4])
    acc &= 0xFFFFFFFF
    return acc == 0


def parse_args() -> argparse.Namespace:
    default_exe = SCRIPT_DIR.parent / "Crackme.exe"

    ap = argparse.ArgumentParser(description="Solve Fatmike #9 serial block-by-block")
    ap.add_argument("--exe", default=str(default_exe), help="Path to Crackme.exe")
    ap.add_argument(
        "--alphabet",
        default=DEFAULT_ALPHABET,
        help="Candidate alphabet (default: uppercase + digits + '-')",
    )
    ap.add_argument("--no-cache", action="store_true", help="Disable step transition cache")
    ap.add_argument("--block", type=int, choices=[1, 2, 3, 4, 5], help="Solve only selected block")
    ap.add_argument("--list-blocks", action="store_true", help="Print block metadata and continue")
    ap.add_argument("--first-only", action="store_true", help="Stop a block solve after first solution")
    ap.add_argument(
        "--pattern",
        default=None,
        help="19-char pattern (X/?/* wildcard). Example: XXXX-XXXX-XXXX-XXXX",
    )
    ap.add_argument("--dash-first", action="store_true", help="Try '-' first in alphabet order")
    ap.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Parallel workers for --block + --first-only mode (default: 1)",
    )
    return ap.parse_args()


def main() -> int:
    args = parse_args()

    exe_path = Path(args.exe)
    if not exe_path.exists():
        print(f"[-] File not found: {exe_path}")
        return 1

    try:
        alphabet = args.alphabet.encode("ascii")
    except UnicodeEncodeError:
        print("[-] Alphabet must be ASCII")
        return 1

    if not alphabet:
        print("[-] Empty alphabet")
        return 1

    if args.dash_first:
        alphabet = reorder_alphabet_dash_first(alphabet)

    pattern = args.pattern
    if pattern is not None:
        if len(pattern) != 19:
            print("[-] --pattern must have exactly 19 chars")
            return 1
        try:
            pattern.encode("ascii")
        except UnicodeEncodeError:
            print("[-] --pattern must be ASCII")
            return 1

    if args.workers < 1:
        print("[-] --workers must be >= 1")
        return 1

    print(f"[+] EXE: {exe_path}")
    print(f"[+] Alphabet ({len(alphabet)}): {alphabet.decode('ascii')}")
    if pattern is not None:
        print(f"[+] Pattern: {pattern}")

    exe_blob = exe_path.read_bytes()
    pe = pefile.PE(data=exe_blob, fast_load=False)

    key, _orig_last = derive_key_from_text(exe_blob, pe)
    dec_pc, _enc_pc = decrypt_pc_full(exe_blob, pe, key)

    ok, msg = verify_gates(dec_pc)
    if not ok:
        print(f"[-] Decrypt verification failed: {msg}")
        return 2

    print(f"[+] Decrypt key: {key.hex()}")
    print("[+] Decrypt gates passed")

    handlers = load_handler_table(pe)
    print(f"[+] Loaded VM handlers: {len(handlers)} entries")

    pc_sec = get_section(pe, b".pc")
    image_base = pe.OPTIONAL_HEADER.ImageBase
    func_rva = pc_sec.VirtualAddress + 0x1CE

    oracle = StepOracle(
        image_base=image_base,
        pc_rva=pc_sec.VirtualAddress,
        pc_bytes=dec_pc,
        handlers=handlers,
        func_rva=func_rva,
    )

    use_cache = not args.no_cache
    step_fn = build_step_with_cache(oracle, use_cache=use_cache)

    starts = block_start_states()

    if args.list_blocks:
        print_block_meta(starts)

    if args.block is not None:
        bi = args.block - 1
        charsets = build_block_charsets(bi, alphabet, pattern)

        if args.first_only and args.workers > 1:
            sols = solve_block_parallel_first(
                step_fn=step_fn,
                start_state=starts[bi],
                target_state=TARGETS[bi],
                charsets=charsets,
                block_index=args.block,
                workers=args.workers,
                image_base=image_base,
                pc_rva=pc_sec.VirtualAddress,
                pc_bytes=dec_pc,
                handlers=handlers,
                func_rva=func_rva,
                use_cache=use_cache,
            )
        else:
            sols = solve_block(
                step_fn,
                start_state=starts[bi],
                target_state=TARGETS[bi],
                charsets=charsets,
                block_index=args.block,
                first_only=args.first_only,
            )

        if not sols:
            print(f"[-] No solutions for block {args.block}. Try broader alphabet/pattern.")
            return 3
        print(f"[+] Block {args.block} done. Solutions: {len(sols)}")
        return 0

    all_block_solutions: list[list[str]] = []

    for bi in range(5):
        charsets = build_block_charsets(bi, alphabet, pattern)
        sols = solve_block(
            step_fn,
            start_state=starts[bi],
            target_state=TARGETS[bi],
            charsets=charsets,
            block_index=bi + 1,
            first_only=args.first_only,
        )
        if not sols:
            print(f"[-] No solutions for block {bi + 1}. Try broader alphabet/pattern.")
            return 3
        all_block_solutions.append(sols)

    print("[+] Combining block candidates and validating full serial...")
    valid = []
    for combo in itertools.product(*all_block_solutions):
        serial = "".join(combo)
        if validate_serial(step_fn, serial):
            valid.append(serial)

    if not valid:
        print("[-] No full serial validated.")
        return 4

    print(f"[+] Valid serial candidate(s): {len(valid)}")
    for s in valid:
        print(f"    {s}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
