import struct
from chacha20_custom import chacha20_decrypt
from capstone import Cs, CS_ARCH_X86, CS_MODE_32

cc_map = {0x01:0x05,0x03:0x08,0x04:0x03,0x05:0x0E,0x06:0x07,0x07:0x0D,0x08:0x0A,0x09:0x00,0x0A:0x06,0x0C:0x0B,0x0D:0x04,0x0E:0x0C,0x0F:0x09,0x10:0x01,0x11:0x0F,0x12:0x02}
cond_name = {0x01:"jnz",0x02:"jmp",0x03:"js",0x04:"jae",0x05:"jle",0x06:"ja",0x07:"jge",0x08:"jp",0x09:"jo",0x0A:"jbe",0x0B:"jecxz",0x0C:"jnp",0x0D:"jz",0x0E:"jl",0x0F:"jns",0x10:"jno",0x11:"jg",0x12:"jb"}


def make_jcc(cond, size, disp):
    if disp == 0:
        return b'\x90' * size
    if cond == 2:
        if -128 <= disp <= 127 and size >= 2:
            op = struct.pack('Bb', 0xEB, disp)
        else:
            op = struct.pack('<Bi', 0xE9, disp)
        return b'\x90' * (size - len(op)) + op

    if cond == 0x0B:
        op = struct.pack('Bb', 0xE3, disp)
        return b'\x90' * (size - len(op)) + op

    cc = cc_map[cond]
    if -128 <= disp <= 127 and size >= 2:
        op = struct.pack('Bb', 0x70 + cc, disp)
    else:
        op = struct.pack('<BBi', 0x0F, 0x80 + cc, disp)
    return b'\x90' * (size - len(op)) + op


key = bytes.fromhex("f630aa38d57297375d645559c334fd50d55ca1d177d2655a042351cf69244bf2")
nonce = bytes.fromhex("0a0b0c0d0e0f1011")
base = 0x40A000
funcs = [0x40A000, 0x40A025]

enc = open("funny.bin", "rb").read()
bd = open("branch_desc.bin", "rb").read()

bd = [struct.unpack('<4i', bd[i:i+16]) for i in range(0, len(bd), 16)]
bd_map ={}
for off,cond,displ,size in bd:
    bd_map[off] = (cond, displ, size)

dec = bytearray(chacha20_decrypt(key, nonce, enc))
with open("decrypted.bin", "wb") as f:
    f.write(dec)
dis = Cs(CS_ARCH_X86, CS_MODE_32)
i = 0
xor_eax = bytes.fromhex("33 C0 83 F8 00")
xor_cmp = bytes.fromhex("33 C0 83 F8")
xor_cmp32 = bytes.fromhex("33 C0 3D")
inc_eax = bytes.fromhex("40 83 f8 00")  
while i < len(dec) - 1:
    print(hex(i+0xa000))
    
    if dec[i] == 0xCC and i+0xA000 in bd_map:
        cond, displ, size = bd_map[i+0xA000]
        new_pos = i+size
        if i > 10 and dec[i-5:i] == xor_eax and cond_name[cond] == "jz":
            dec[i:i+size] = make_jcc(2, size, displ)
            i = i + size + displ
        elif i >= 5 and dec[i-5:i-1] == xor_cmp and cond_name[cond] == "jnz":
            dec[i:i+size] = make_jcc(2, size, displ)
            i = i + size + displ
        elif i >= 7 and dec[i-7:i-4] == xor_cmp32 and cond_name[cond] == "jnz":
            dec[i:i+size] = make_jcc(2, size, displ)
            i = i + size + displ
        elif i > 10 and dec[i-4:i] == inc_eax and cond_name[cond] == "jnz":
            dec[i:i+size] = make_jcc(2, size, displ)
            i = i + size + displ
        elif i >= 1 and dec[i-1] == 0x40 and cond_name[cond] == "jnz":
            dec[i:i+size] = make_jcc(2, size, displ)
            print(hex(0x400000 + i - 1), "is inc eax")
            i = i + size + displ
        else:
            dec[i:i+size] = make_jcc(cond, size, displ)
            i = new_pos
    elif dec[i] == 0xB8 and i + 6 < len(dec) and dec[i+5] == 0xFF and dec[i+6] == 0xE0:
        target = struct.unpack_from('<I', dec, i+1)[0]
        rel = target - (base + i + 5)
        dec[i:i+7] = struct.pack('<Bi', 0xE9, rel) + b'\x90\x90'
        i = target - base
    elif dec[i] == 0xB8 and i + 6 < len(dec) and dec[i+5] == 0x50 and dec[i+6] == 0xC3:
        target = struct.unpack_from('<I', dec, i+1)[0]
        rel = target - (base + i + 5)
        dec[i:i+7] = struct.pack('<Bi', 0xE9, rel) + b'\x90\x90'
        i = target - base
    elif dec[i] == 0x68 and i + 5 < len(dec) and dec[i+5] == 0xC3:
        target = struct.unpack_from('<I', dec, i+1)[0]
        rel = target - (base + i + 5)
        dec[i:i+6] = struct.pack('<Bi', 0xE9, rel) + b'\x90'
        i = target - base
    else:
        r = list(dis.disasm(bytes(dec[i:i+15]), base + i, count=1))
        i += r[0].size if r else 1


pc_off = 0x8E00
pc_sz = 0x600

exe = bytearray(open("Crackme.exe", "rb").read())
n = min(len(dec), pc_sz)
exe[pc_off:pc_off + n] = dec[:n]
open("Crackme_patched2.exe", "wb").write(exe)