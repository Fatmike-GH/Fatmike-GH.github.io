# Fatmike's Fatmike's Crackme #10 (crackmes.one CTF 2026) WRITEUP


## Description of the challenge

The challenge consists of a window with 3 buttons, one of which is labeled as "PLAY" and uppon a click, a distorted sound starts playing in the background, according to the challenge hints, our goal is to fix two problems in the sound:
1. It is reversed
2. It's also pitched up or down


## Process That Worked

	1. First I loaded the program into x64dbg and looked at the IMPORTS from "recordplayer.exe" in the Symbols window
	2. Looking for anything that was audio related there were some functions: winmm.waveOutOpen, winmm.waveOutWrite, winmm.waveOutReset, winmm.waveOutPrepareHeader, winmm.waveOutUnprepareHeader, ...
	I recognized them as being AUDIO related because of the WAVE format, but winmm stands for the [Windows Multimedia API](https://en.wikipedia.org/wiki/Windows_legacy_audio_components)
	3. Recognizing that the program has to call winmm.waveOutOpen to start a stream of audio, I put a breakpoint on it
	4. Pressing "PLAY" inside the program window hits the breakpoint previously set.
	5. By looking at the call stack we can see that the system upon the event calls user code. Going to the start of the current function we can see:
	6. Some functions from the program are called but there are two special functions whose arguments seem a little bit odd.
	7. The assembly shows that the argument at dl is 1 for two called functions. I assumed this "mov dl, 1" meant a TRUE value, a boolean that could be controlling the reversed effect
	8. By changing the instruction to mov dl, 0 and letting the program run, we get a more recognizable sound.
	9. By doing the same to the function after the latter (it has the same arguments) and letting the program run we finally end up getting rickrolled! And also we get the flag
	10. A window pop up saying congratulations and we end up with the flag: CMO{y0u_g0t_r1ckr0ll3d}
	

## Disclaimer

I tried other things too such as looking for the string PLAY, which didn't work (also probably wouldn't have helped since buttons work via BUTTON ID's and not strings I believe)  
Also thought the program used the [PlaySound](https://learn.microsoft.com/en-us/windows/win32/multimedia/the-playsound-function) function, but I was wrong (also it is legacy code now)  
I tried looking at WndProc but the window generated from this program uses [DialogBoxParamW](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-dialogboxparamw), so it creates windows in a non standard way
  
  

Author: n.qber